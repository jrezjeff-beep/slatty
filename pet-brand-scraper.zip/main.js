import { Actor } from 'apify';
import { PuppeteerCrawler, Dataset } from 'crawlee';

await Actor.init();

const keywords = [
    'dog supplement',
    'calming chews',
    'dog anxiety',
    'freeze dried dog food',
    'pet wellness',
    'dog probiotics',
    'senior dog care',
    'skin coat dog'
];

const results = new Map(); // deduplicate by domain

// ─── HELPER: extract root domain ───────────────────────────────────────────
function extractDomain(url) {
    try {
        const u = new URL(url.startsWith('http') ? url : `https://${url}`);
        return u.hostname.replace(/^www\./, '');
    } catch {
        return url;
    }
}

// ─── HELPER: rough follower count from text ─────────────────────────────────
function parseFollowers(text) {
    if (!text) return '';
    const match = text.match(/([\d,.]+)\s*[Kk]?\s*(followers|likes|fans)/i);
    if (!match) return '';
    let num = parseFloat(match[1].replace(/,/g, ''));
    if (/k/i.test(match[0])) num *= 1000;
    return Math.round(num).toString();
}

// ─── SOURCES TO CRAWL ───────────────────────────────────────────────────────
const startUrls = [];

for (const kw of keywords) {
    const encoded = encodeURIComponent(kw);

    // 1. Meta Ad Library search
    startUrls.push({
        url: `https://www.facebook.com/ads/library/?active_status=active&ad_type=all&country=US&q=${encoded}&search_type=keyword_unordered&media_type=all`,
        label: 'META',
        keyword: kw
    });

    // 2. Google search — brand directory angle
    startUrls.push({
        url: `https://www.google.com/search?q=${encoded}+brand+site%3Ashopify.com+OR+site%3Amyshopify.com+-site%3Aamazon.com`,
        label: 'GOOGLE',
        keyword: kw
    });

    // 3. my-ip.ms directory (shows Facebook page owners by category)
    startUrls.push({
        url: `https://my-ip.ms/info/social-facebook/search/?q=${encoded}`,
        label: 'MYIPMS',
        keyword: kw
    });
}

const crawler = new PuppeteerCrawler({
    launchContext: {
        launchOptions: {
            headless: true,
            args: ['--no-sandbox', '--disable-setuid-sandbox']
        }
    },
    maxRequestsPerCrawl: 200,
    requestHandlerTimeoutSecs: 60,

    async requestHandler({ request, page, log }) {
        const { label, keyword } = request.userData ?? request;
        log.info(`Scraping [${label}] for keyword: ${keyword}`);

        await page.waitForTimeout(2000 + Math.random() * 1000);

        // ── META AD LIBRARY ─────────────────────────────────────────────────
        if (label === 'META') {
            await page.waitForTimeout(4000); // JS-heavy page
            const brands = await page.evaluate(() => {
                const items = [];
                // Ad library cards contain advertiser name + page link
                document.querySelectorAll('a[href*="facebook.com/ads/library"]').forEach(el => {
                    const text = el.innerText?.trim();
                    const href = el.href;
                    if (text && href) items.push({ name: text, fbUrl: href });
                });
                // Also grab advertiser name spans
                document.querySelectorAll('[data-testid="ad_library_preview_card"]').forEach(card => {
                    const nameEl = card.querySelector('strong, [role="heading"]');
                    const linkEl = card.querySelector('a[href*="facebook.com"]');
                    if (nameEl && linkEl) {
                        items.push({ name: nameEl.innerText.trim(), fbUrl: linkEl.href });
                    }
                });
                return items;
            });

            for (const brand of brands) {
                if (!brand.name || brand.name.length < 2) continue;
                const key = brand.name.toLowerCase().replace(/\s+/g, '');
                if (!results.has(key)) {
                    results.set(key, {
                        brand_name: brand.name,
                        url: '',
                        estimated_followers: '',
                        source: 'Meta Ad Library',
                        keyword
                    });
                }
            }
        }

        // ── GOOGLE SEARCH ───────────────────────────────────────────────────
        if (label === 'GOOGLE') {
            const hits = await page.evaluate(() => {
                const items = [];
                document.querySelectorAll('div.g, div[data-hveid]').forEach(result => {
                    const titleEl = result.querySelector('h3');
                    const linkEl = result.querySelector('a[href]');
                    const snippetEl = result.querySelector('.VwiC3b, span.st');
                    if (titleEl && linkEl) {
                        items.push({
                            title: titleEl.innerText.trim(),
                            url: linkEl.href,
                            snippet: snippetEl?.innerText ?? ''
                        });
                    }
                });
                return items;
            });

            for (const hit of hits) {
                const domain = extractDomain(hit.url);
                if (!domain || domain.includes('google') || domain.includes('facebook')) continue;
                // filter out obvious non-brands
                if (['amazon', 'chewy', 'walmart', 'petco', 'petsmart', 'reddit', 'youtube'].some(s => domain.includes(s))) continue;

                const followers = parseFollowers(hit.snippet);
                if (!results.has(domain)) {
                    results.set(domain, {
                        brand_name: hit.title.replace(/\s*[-|].*$/, '').trim(),
                        url: `https://${domain}`,
                        estimated_followers: followers,
                        source: 'Google Search',
                        keyword
                    });
                } else if (!results.get(domain).estimated_followers && followers) {
                    results.get(domain).estimated_followers = followers;
                }
            }
        }

        // ── MY-IP.MS DIRECTORY ──────────────────────────────────────────────
        if (label === 'MYIPMS') {
            const rows = await page.evaluate(() => {
                const items = [];
                document.querySelectorAll('table tr').forEach(row => {
                    const cells = row.querySelectorAll('td');
                    if (cells.length >= 3) {
                        const name = cells[0]?.innerText?.trim();
                        const url = cells[1]?.querySelector('a')?.href ?? cells[1]?.innerText?.trim();
                        const fans = cells[2]?.innerText?.trim();
                        if (name && url) items.push({ name, url, fans });
                    }
                });
                return items;
            });

            for (const row of rows) {
                const domain = extractDomain(row.url);
                if (!domain) continue;
                if (!results.has(domain)) {
                    results.set(domain, {
                        brand_name: row.name,
                        url: row.url.startsWith('http') ? row.url : `https://${domain}`,
                        estimated_followers: row.fans?.replace(/[^\d]/g, '') ?? '',
                        source: 'my-ip.ms',
                        keyword
                    });
                }
            }
        }
    },

    failedRequestHandler({ request, log }) {
        log.warning(`Failed: ${request.url}`);
    }
});

// inject userData into requests
const requests = startUrls.map(s => ({
    url: s.url,
    userData: { label: s.label, keyword: s.keyword }
}));

await crawler.run(requests);

// ─── SAVE TO DATASET (Apify auto-exports as CSV) ────────────────────────────
const finalResults = Array.from(results.values()).filter(r => r.brand_name && r.brand_name.length > 1);

console.log(`\n✅ Total unique brands found: ${finalResults.length}`);

await Dataset.pushData(finalResults);

await Actor.exit();
